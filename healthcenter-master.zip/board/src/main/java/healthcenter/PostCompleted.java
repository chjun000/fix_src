package healthcenter;

public class PostCompleted extends AbstractEvent {

    private Long id;
    private Long orderId;
    private String boardYn;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getBoardYn() {
        return boardYn;
    }

    public void setBoardYn(String boardYn) {
        this.boardYn = boardYn;
    }

}

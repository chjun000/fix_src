package healthcenter;

import org.springframework.data.repository.PagingAndSortingRepository;


public interface BoardRepository extends PagingAndSortingRepository<Board, Long>{
    Board findByOrderId(Long orderId);

}


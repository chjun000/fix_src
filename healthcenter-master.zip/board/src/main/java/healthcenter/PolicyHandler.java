package healthcenter;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import healthcenter.config.kafka.KafkaProcessor;


@Service
public class PolicyHandler {
    @Autowired
    BoardRepository boardRepository;

    @StreamListener(KafkaProcessor.INPUT)
    public void onStringEventListener(@Payload String eventString) {

    }


    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverReserveAccepted_(@Payload ReserveAccepted reserveAccepted) {

        System.out.println(reserveAccepted);

        if (reserveAccepted.isMe()) {
            System.out.println("##### listener  : " + reserveAccepted.toJson());
            Board board = new Board();
            board.setOrderId(reserveAccepted.getOrderId());
            board.setBoardYn("Y");
            boardRepository.save(board);
        }

    }

    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverReserveCanceled_(@Payload ReserveCanceled reserveCanceled) {

        if (reserveCanceled.isMe()) {
            System.out.println("##### listener  : " + reserveCanceled.toJson());

            Board board = boardRepository.findByOrderId(reserveCanceled.getOrderId());
            board.setBoardYn("N");
            boardRepository.save(board);


        }
    }
}
